/*global app*/
(function () {
"use strict";

app.init(document.querySelectorAll('#main-nav button'));

})();